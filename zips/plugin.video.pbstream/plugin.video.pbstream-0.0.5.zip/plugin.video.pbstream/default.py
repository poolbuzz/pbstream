#!/usr/bin/python

# *  This Program is free software; you can redistribute it and/or modify
# *  it under the terms of the GNU General Public License as published by
# *  the Free Software Foundation; either version 2, or (at your option)
# *  any later version.
# *
# *  This Program is distributed in the hope that it will be useful,
# *  but WITHOUT ANY WARRANTY; without even the implied warranty of
# *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# *  GNU General Public License for more details.
# *
# *  You should have received a copy of the GNU General Public License
# *  along with XBMC; see the file COPYING.  If not, write to
# *  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
# *  http://www.gnu.org/copyleft/gpl.html

import os, sys, urllib, urlparse
import xbmcgui, xbmcplugin, xbmcaddon
import base64, zlib
from urllib2 import Request, urlopen, URLError, HTTPError

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urlparse.parse_qs(sys.argv[2][1:])
_id = 'plugin.video.pbstream'
addon = xbmcaddon.Addon(_id)
icon = addon.getAddonInfo('icon')
title = addon.getAddonInfo('name')
__cwd__ = xbmc.translatePath(addon.getAddonInfo('path')).decode("utf-8")
_icondir = __cwd__ + "/icons"
PBStreamLiveTVFile = "https://s3.amazonaws.com/pbstream/users/PBStreamLiveTV.txt"

xbmcplugin.setContent(addon_handle, 'movies')
debug = "true"

def Debug(msg, force = False):
    if(debug == "true" or force):
        try:
            print "#####[PBStream]##### " + msg
        except UnicodeEncodeError:
            print "#####[PBStream]##### " + msg.encode( "utf-8", "ignore" )

def build_url(query):
    return base_url + '?' + urllib.urlencode(query)

def add_video_item(url, infolabels, img=''):
    if (os.path.exists(img) == False):
        img = icon
    listitem = xbmcgui.ListItem(infolabels['title'], iconImage=img, thumbnailImage=img)
    listitem.setInfo('Video', infolabels)
    listitem.setProperty('IsPlayable', 'true')
    xbmcplugin.addDirectoryItem(addon_handle, url, listitem, isFolder=False)

def add_menu_item(url, infolabels, img=''):
    listitem = xbmcgui.ListItem(infolabels['title'], iconImage=img, thumbnailImage=img)
    xbmcplugin.addDirectoryItem(addon_handle, url, listitem, isFolder=True)

def playMedia(title, thumbnail, link, mediaType='Video') :
    """Plays a video
    Arguments:
    title: the title to be displayed
    thumbnail: the thumnail to be used as an icon and thumbnail
    link: the link to the media to be played
    mediaType: the type of media to play, defaults to Video. Known values are Video, Pictures, Music and Programs
    """
    li = xbmcgui.ListItem(label=title, iconImage=thumbnail, thumbnailImage=thumbnail, path=link)
    li.setInfo(type=mediaType, infoLabels={ "Title": title })
    xbmc.Player().play(item=link, listitem=li)

mode = args.get('mode', None)

if mode is None:
    url = build_url({'mode': 'folder', 'foldername': 'Folder One'})
    add_menu_item(url, {'title': 'Demo'}, icon)

    url = build_url({'mode': 'folder', 'foldername': 'Folder Two'})
    add_menu_item(url, {'title': 'LiveTV'}, icon)

    url = build_url({'mode': 'folder', 'foldername': 'Folder Three'})
    add_menu_item(url, {'title': 'Update Kodi'}, icon)

    xbmcplugin.endOfDirectory(addon_handle)

elif mode[0] == 'folder':
    foldername = args['foldername'][0]
    if (foldername == "Folder One"):
        url = 'plugin://plugin.video.youtube/?action=play_video&videoid=fsw8kK_tLnc'
        playMedia("PBStream Demo", icon, url)

    if (foldername == "Folder Two"):
        req = Request(PBStreamLiveTVFile)
        try:
            f = urlopen(req)
            PBStreamLiveTVList = f.read()
            data = zlib.decompress(base64.b64decode(PBStreamLiveTVList.decode("hex")))
            PBStreamLiveTVList = data.split("\n")
            for line in PBStreamLiveTVList:
                url, ListTitle, img = line.split('^')
                Debug("ImagePath = %s/%s" % (_icondir, img))
                add_video_item(url, {'title': ListTitle}, "%s/%s" % (_icondir, img))
        except HTTPError, e:
            Debug("HTTPError")
        except URLError, e:
            Debug("URLError")

        xbmcplugin.endOfDirectory(addon_handle)
        xbmc.executebuiltin("Container.SetViewMode(500)")

    if (foldername == "Folder Three"):
        if (xbmcgui.Dialog().yesno("PBStream", "The Script will get updates from PBStream server\nDo you want to continue?")):
            xbmcgui.Dialog().ok("PBStream", "Under Development, Available Soon...\n", "Thanks")