service.pbstream-lic
====================

Automatically Check/Update Login Details on Playback.<br>

Configuration options:
- Debug
- Username
- Password
- EMail